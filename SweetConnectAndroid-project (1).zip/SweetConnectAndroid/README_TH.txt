SweetConnect Android project

โปรเจกต์นี้นำไฟล์ HTML เดิมไปแสดงใน Android WebView โดยคงหน้าตาเดิมไว้

ข้อจำกัดของ HTML ต้นฉบับ:
- แชทเป็นเพียงการแสดงข้อความในเครื่อง ยังไม่ส่งไปยังอีกคน
- GPS แสดงตำแหน่งของเครื่องที่อนุญาตเท่านั้น ยังไม่มีการแชร์ตำแหน่งระหว่างบัญชี
- Tailwind, Font Awesome, Leaflet และแผนที่โหลดจากอินเทอร์เน็ต จึงต้องเชื่อมต่ออินเทอร์เน็ต
- การแจ้งเตือนจากหน้าเว็บอาจไม่ทำงานเหมือน push notification ของแอปจริง

การสร้าง APK:
1. เปิดโปรเจกต์นี้ด้วย Android Studio แล้วรอ Gradle Sync
2. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
3. ไฟล์ debug APK จะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk

หรืออัปโหลดโฟลเดอร์นี้ขึ้น GitHub แล้วใช้ Actions > Build SweetConnect APK > Run workflow
จากนั้นดาวน์โหลด artifact ชื่อ SweetConnect-debug-apk
